import SwiftUI

@main
struct SonnerieProfApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
