import Combine
import Foundation
import WidgetKit

@MainActor
final class SiteStore: ObservableObject {

    static let maximumSiteCount = 4

    @Published var sites: [BellSite]
    @Published var selectedSiteID: UUID?
    @Published var scheduleSuspendedUntil: Date?

    private let repository = SiteRepository()

    init() {
        let loaded = repository.loadSites()
        self.sites = loaded
        self.selectedSiteID = repository.selectedSiteID() ?? loaded.first?.id

        let storedSuspension = repository.scheduleSuspendedUntil()
        self.scheduleSuspendedUntil = (storedSuspension ?? .distantPast) > Date.now
            ? storedSuspension
            : nil

        if let selectedSiteID,
           !loaded.contains(where: { $0.id == selectedSiteID }) {
            self.selectedSiteID = loaded.first?.id
        }

        persist()
    }

    var selectedSite: BellSite? {
        if let selectedSiteID,
           let selected = sites.first(where: { $0.id == selectedSiteID }) {
            return selected
        }
        return sites.first
    }

    var canAddSite: Bool {
        sites.count < Self.maximumSiteCount
    }

    var remainingSiteSlots: Int {
        max(0, Self.maximumSiteCount - sites.count)
    }

    var isScheduleSuspended: Bool {
        guard let until = scheduleSuspendedUntil else { return false }
        return until > Date.now
    }

    func select(_ site: BellSite) {
        selectedSiteID = site.id
        persist()
    }

    func update(_ site: BellSite) {
        var normalizedSite = site
        normalizedSite.name = site.name.trimmingCharacters(in: .whitespacesAndNewlines)

        if let index = sites.firstIndex(where: { $0.id == normalizedSite.id }) {
            sites[index] = normalizedSite
        } else {
            guard canAddSite else { return }
            sites.append(normalizedSite)

            if selectedSiteID == nil {
                selectedSiteID = normalizedSite.id
            }
        }

        persist()
    }

    func delete(_ site: BellSite) {
        sites.removeAll { $0.id == site.id }

        if selectedSiteID == site.id {
            selectedSiteID = sites.first?.id
        }

        persist()
    }

    func suspendSchedule(until date: Date) {
        let normalized = Calendar.current.startOfDay(for: date)
        scheduleSuspendedUntil = normalized
        persist()
    }

    func resumeSchedule() {
        scheduleSuspendedUntil = nil
        persist()
    }

    func persist() {
        repository.saveSites(sites)
        repository.setSelectedSiteID(selectedSiteID)
        repository.setScheduleSuspendedUntil(scheduleSuspendedUntil)
        WidgetCenter.shared.reloadAllTimelines()
    }
}
