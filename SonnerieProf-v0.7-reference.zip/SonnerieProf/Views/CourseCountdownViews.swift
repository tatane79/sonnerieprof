import SwiftUI

struct CourseCountdownCard: View {
    let sessions: [CourseSession]
    let sites: [BellSite]
    let referenceWeekStart: Date
    let referenceWeek: TeachingWeek
    let fallbackSite: BellSite?
    let suspendedUntil: Date?
    let timeOffset: TimeInterval
    let onShowFullscreen: () -> Void

    private let engine = TimetableEngine()
    private let bellEngine = ScheduleEngine()

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            let displayDate = context.date.addingTimeInterval(timeOffset)
            let status = engine.status(
                at: displayDate,
                sessions: sessions,
                referenceWeekStart: referenceWeekStart,
                referenceWeek: referenceWeek
            )
            let fallbackBell = sessions.isEmpty
                ? fallbackSite.flatMap {
                    bellEngine.nextBell(
                        after: displayDate,
                        at: $0,
                        suspendedUntil: suspendedUntil
                    )
                }
                : nil

            if let target = status.current?.endDate ?? status.next?.startDate ?? fallbackBell {
                let systemTarget = target.addingTimeInterval(-timeOffset)
                let occurrence = status.current ?? status.next

                VStack(spacing: 16) {
                    if let occurrence {
                        Text(occurrence.session.className)
                            .font(.title.bold())
                            .accessibilityAddTraits(.isHeader)

                        HStack(spacing: 12) {
                            Label(
                                occurrence.session.roomName,
                                systemImage: "door.left.hand.open"
                            )

                            if let siteName = siteName(for: occurrence.session.siteID) {
                                Label(siteName, systemImage: "building.2")
                            }
                        }
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    } else if let fallbackSite {
                        Text(fallbackSite.name)
                            .font(.title.bold())
                            .accessibilityAddTraits(.isHeader)
                    }

                    Text(
                        timerInterval: context.date...systemTarget,
                        pauseTime: systemTarget,
                        countsDown: true,
                        showsHours: true
                    )
                    .font(.system(.largeTitle, design: .rounded, weight: .bold))
                    .monospacedDigit()
                    .minimumScaleFactor(0.45)
                    .accessibilityLabel("Temps restant")

                    Text(targetLabel(status: status, target: target, isFallbackBell: fallbackBell != nil))
                        .font(.headline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 36)
                .padding(.horizontal)
                .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 24))
                .overlay(alignment: .topTrailing) {
                    Button(action: onShowFullscreen) {
                        Image(systemName: "arrow.up.left.and.arrow.down.right")
                            .font(.headline.weight(.semibold))
                            .padding(10)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel("Afficher en plein écran")
                    .padding(6)
                }
            } else {
                ContentUnavailableView(
                    "Aucun cours programmé",
                    systemImage: "calendar.badge.exclamationmark",
                    description: Text("Ajoutez vos séances dans l’emploi du temps.")
                )
            }
        }
    }

    private func targetLabel(
        status: CourseStatus,
        target: Date,
        isFallbackBell: Bool
    ) -> String {
        let time = target.formatted(.dateTime.hour().minute())
        if isFallbackBell {
            return "Prochaine sonnerie à \(time)"
        }
        if status.current != nil {
            return "Fin du cours à \(time)"
        }
        return "Début du prochain cours à \(time)"
    }

    private func siteName(for id: UUID) -> String? {
        sites.first(where: { $0.id == id })?.name
    }
}

struct CourseFullscreenCountdownView: View {
    @Environment(\.dismiss) private var dismiss

    let sessions: [CourseSession]
    let sites: [BellSite]
    let referenceWeekStart: Date
    let referenceWeek: TeachingWeek
    let fallbackSite: BellSite?
    let suspendedUntil: Date?
    let timeOffset: TimeInterval

    private let engine = TimetableEngine()
    private let bellEngine = ScheduleEngine()

    var body: some View {
        GeometryReader { geometry in
            TimelineView(.periodic(from: .now, by: 1)) { context in
                let displayDate = context.date.addingTimeInterval(timeOffset)
                let status = engine.status(
                    at: displayDate,
                    sessions: sessions,
                    referenceWeekStart: referenceWeekStart,
                    referenceWeek: referenceWeek
                )
                let fallbackBell = sessions.isEmpty
                    ? fallbackSite.flatMap {
                        bellEngine.nextBell(
                            after: displayDate,
                            at: $0,
                            suspendedUntil: suspendedUntil
                        )
                    }
                    : nil

                ZStack {
                    Color.black.ignoresSafeArea()

                    if let target = status.current?.endDate ?? status.next?.startDate ?? fallbackBell {
                        let systemTarget = target.addingTimeInterval(-timeOffset)
                        let occurrence = status.current ?? status.next

                        VStack(spacing: 24) {
                            if let occurrence {
                                Text(occurrence.session.className)
                                    .font(.system(size: min(geometry.size.width * 0.1, 48), weight: .bold, design: .rounded))
                                    .foregroundStyle(.white)

                                HStack(spacing: 16) {
                                    Label(occurrence.session.roomName, systemImage: "door.left.hand.open")

                                    if let siteName = sites.first(where: { $0.id == occurrence.session.siteID })?.name {
                                        Label(siteName, systemImage: "building.2")
                                    }
                                }
                                .font(.title3)
                                .foregroundStyle(.white.opacity(0.7))
                            } else if let fallbackSite {
                                Text(fallbackSite.name)
                                    .font(.system(size: min(geometry.size.width * 0.1, 48), weight: .bold, design: .rounded))
                                    .foregroundStyle(.white)
                            }

                            Text(
                                timerInterval: context.date...systemTarget,
                                pauseTime: systemTarget,
                                countsDown: true,
                                showsHours: true
                            )
                            .font(.system(size: min(geometry.size.width * 0.28, 160), weight: .bold, design: .rounded))
                            .monospacedDigit()
                            .minimumScaleFactor(0.3)
                            .lineLimit(1)
                            .foregroundStyle(.white)

                            Text(targetLabel(status: status, target: target, isFallbackBell: fallbackBell != nil))
                                .font(.title2.weight(.semibold))
                                .foregroundStyle(.white.opacity(0.75))
                        }
                        .padding(30)
                    } else {
                        ContentUnavailableView(
                            "Aucun cours programmé",
                            systemImage: "calendar.badge.exclamationmark"
                        )
                        .foregroundStyle(.white)
                    }
                }
            }
        }
        .overlay(alignment: .topTrailing) {
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.largeTitle)
                    .symbolRenderingMode(.hierarchical)
            }
            .foregroundStyle(.white)
            .padding()
            .accessibilityLabel("Fermer")
        }
        .persistentSystemOverlays(.hidden)
    }

    private func targetLabel(
        status: CourseStatus,
        target: Date,
        isFallbackBell: Bool
    ) -> String {
        let time = target.formatted(.dateTime.hour().minute())
        if isFallbackBell {
            return "Prochaine sonnerie à \(time)"
        }
        if status.current != nil {
            return "Fin du cours à \(time)"
        }
        return "Début du prochain cours à \(time)"
    }
}
