import Foundation
import Observation
import WidgetKit

@MainActor
@Observable
final class TimetableStore {
    var sessions: [CourseSession] {
        didSet {
            sortSessions()
            repository.saveSessions(sessions)
            WidgetCenter.shared.reloadAllTimelines()
        }
    }

    private(set) var sortedSessions: [CourseSession]
    var referenceWeekStart: Date
    var referenceWeek: TeachingWeek
    private(set) var q1Name: String
    private(set) var q2Name: String

    private let repository: TimetableRepository
    private let engine: TimetableEngine

    init(
        repository: TimetableRepository = TimetableRepository(),
        engine: TimetableEngine = TimetableEngine()
    ) {
        self.repository = repository
        self.engine = engine

        let loaded = repository.loadSessions()
        self.sessions = loaded
        self.sortedSessions = loaded.sorted(by: Self.sessionOrder)
        self.referenceWeekStart = repository.referenceWeekStart()
            ?? engine.startOfWeek(containing: .now)
        self.referenceWeek = repository.referenceWeek()
        self.q1Name = repository.weekName(for: .q1)
        self.q2Name = repository.weekName(for: .q2)
    }

    func save(_ session: CourseSession) {
        var normalized = session
        normalized.className = session.className.trimmingCharacters(in: .whitespacesAndNewlines)
        normalized.roomName = session.roomName.trimmingCharacters(in: .whitespacesAndNewlines)

        if let index = sessions.firstIndex(where: { $0.id == normalized.id }) {
            sessions[index] = normalized
        } else {
            sessions.append(normalized)
        }
    }

    func delete(_ session: CourseSession) {
        sessions.removeAll { $0.id == session.id }
    }

    var displayedCurrentWeek: TeachingWeek {
        get { currentWeek() }
        set { setCurrentWeek(newValue) }
    }

    func setCurrentWeek(_ week: TeachingWeek, at date: Date = .now) {
        referenceWeek = week
        referenceWeekStart = engine.startOfWeek(containing: date)
        repository.setReferenceWeek(week)
        repository.setReferenceWeekStart(referenceWeekStart)
        WidgetCenter.shared.reloadAllTimelines()
    }

    func currentWeek(at date: Date = .now) -> TeachingWeek {
        engine.teachingWeek(
            on: date,
            referenceWeekStart: referenceWeekStart,
            referenceWeek: referenceWeek
        )
    }

    func weekName(for week: TeachingWeek) -> String {
        let name = week == .q1 ? q1Name : q2Name
        let normalized = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized.isEmpty ? (week == .q1 ? "Q1" : "Q2") : normalized
    }

    func setWeekName(_ name: String, for week: TeachingWeek) {
        if week == .q1 {
            q1Name = name
        } else {
            q2Name = name
        }

        repository.setWeekName(name, for: week)
        WidgetCenter.shared.reloadAllTimelines()
    }

    private func sortSessions() {
        sortedSessions = sessions.sorted(by: Self.sessionOrder)
    }

    private static func sessionOrder(_ lhs: CourseSession, _ rhs: CourseSession) -> Bool {
        if lhs.weekday != rhs.weekday {
            return lhs.weekday < rhs.weekday
        }
        if lhs.startMinutes != rhs.startMinutes {
            return lhs.startMinutes < rhs.startMinutes
        }
        return lhs.className.localizedCaseInsensitiveCompare(rhs.className) == .orderedAscending
    }
}
