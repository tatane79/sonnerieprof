import ActivityKit
import SwiftUI
import WidgetKit

private struct BellCountdownView: View {
    let context: ActivityViewContext<BellActivityAttributes>
    var showsSystemTimer = false

    var body: some View {
        // La vue change de cible aux dates exactes des sonneries tandis que
        // le Text temporel natif anime le décompte sans réveiller l'extension.
        TimelineView(
            .explicit([context.state.startDate] + context.state.bellDates)
        ) { timeline in
            if let nextBell = nextBell(after: timeline.date) {
                if shouldHideUntilReveal(
                    at: timeline.date,
                    nextBell: nextBell
                ) {
                    EmptyView()
                } else {
                    minutesText(to: nextBell, at: timeline.date)
                }
            } else {
                Text(verbatim: "—")
            }
        }
    }

    private func nextBell(after date: Date) -> Date? {
        context.state.bellDates.first(where: { $0 > date })
    }

    private func displayDate(for systemDate: Date) -> Date {
        systemDate.addingTimeInterval(
            context.state.simulatedTimeOffset ?? 0
        )
    }

    private func shouldHideUntilReveal(
        at systemDate: Date,
        nextBell: Date
    ) -> Bool {
        guard AfterLastBellBridge.shouldHideUntilOneHourBefore else {
            return false
        }

        let displayNow = displayDate(for: systemDate)
        let displayBell = displayDate(for: nextBell)

        // Une sonnerie est encore prévue aujourd'hui : affichage normal.
        guard !Calendar.autoupdatingCurrent.isDate(
            displayNow,
            inSameDayAs: displayBell
        ) else {
            return false
        }

        // Après la dernière sonnerie du jour, on masque jusqu'à H-1.
        return systemDate < nextBell.addingTimeInterval(-60 * 60)
    }

    @ViewBuilder
    private func minutesText(to targetDate: Date, at currentDate: Date) -> some View {
        if showsSystemTimer {
            Text(
                .currentDate,
                format: .timer(
                    countingDownIn: currentDate..<targetDate,
                    showsHours: false,
                    maxFieldCount: 2,
                    maxPrecision: .seconds(1)
                )
            )
            .monospacedDigit()
        } else {
            Text(
                .currentDate,
                format: .offset(
                    to: targetDate,
                    allowedFields: [.minute],
                    maxFieldCount: 1,
                    sign: .never
                )
            )
            .monospacedDigit()
        }
    }
}

struct NextBellLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: BellActivityAttributes.self) { context in
            // Écran verrouillé / Always-On : nom du site + minutes restantes.
            VStack(spacing: 6) {
                Text(context.attributes.siteName)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .foregroundStyle(.secondary)

                BellCountdownView(context: context)
                    .font(
                        .system(
                            size: 48,
                            weight: .bold,
                            design: .rounded
                        )
                    )
                    .minimumScaleFactor(0.55)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .center)
            .padding()
            .environment(\.locale, appDisplayLocale())
            .activityBackgroundTint(.black.opacity(0.88))
            .activitySystemActionForegroundColor(.white)

        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.center) {
                    EmptyView()
                }
            } compactLeading: {
                Image(systemName: "bell.fill")
                    .font(.caption2)
                    .foregroundStyle(.white)

            } compactTrailing: {
                BellCountdownView(context: context, showsSystemTimer: true)
                    .font(.caption2)
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
                    .frame(width: 40, alignment: .trailing)

            } minimal: {
                Image(systemName: "bell.fill")
            }
        }
    }
}
