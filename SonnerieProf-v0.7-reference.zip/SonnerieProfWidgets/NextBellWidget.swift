import SwiftUI
import WidgetKit

struct NextBellEntry: TimelineEntry {
    /// System-clock date used by WidgetKit to activate this entry.
    let date: Date
    let siteName: String

    /// System-clock start and target dates used by SwiftUI's bounded timer.
    let intervalStart: Date
    let nextBellDate: Date?

    /// Effective app dates. In Release they are identical to the system dates;
    /// in Debug they can represent the simulated developer clock.
    let displayDate: Date
    let displayNextBellDate: Date?

    /// True when the target is the first configured bell of its displayed day.
    /// This lets the widget implement “hide until one hour before” without
    /// accidentally hiding a long gap in the middle of a school day.
    let nextBellIsFirstOfDay: Bool
}

struct NextBellProvider: TimelineProvider {
    private let engine = ScheduleEngine()
    private let timetableEngine = TimetableEngine()
    private let repository = SiteRepository()
    private let timetableRepository = TimetableRepository()
    private let calendar = Calendar.autoupdatingCurrent

    func placeholder(in context: Context) -> NextBellEntry {
        let now = Date.now
        let bell = now.addingTimeInterval(32 * 60)
        return NextBellEntry(
            date: now,
            siteName: L("Mon établissement"),
            intervalStart: now,
            nextBellDate: bell,
            displayDate: now,
            displayNextBellDate: bell,
            nextBellIsFirstOfDay: false
        )
    }

    func getSnapshot(
        in context: Context,
        completion: @escaping (NextBellEntry) -> Void
    ) {
        let systemNow = Date.now
        let displayNow = DebugClockBridge.effectiveDate(for: systemNow)
        let site = repository.activeSite()
        let sessions = timetableRepository.loadSessions()
        let referenceWeekStart = timetableRepository.referenceWeekStart()
            ?? timetableEngine.startOfWeek(containing: displayNow)
        let referenceWeek = timetableRepository.referenceWeek()
        let suspension = repository.scheduleSuspendedUntil()
        let displayBell: Date?

        if sessions.isEmpty, let site {
            displayBell = engine.nextBell(
                after: displayNow,
                at: site,
                suspendedUntil: suspension
            )
        } else {
            displayBell = timetableEngine.countdownTarget(
                at: displayNow,
                sessions: sessions,
                referenceWeekStart: referenceWeekStart,
                referenceWeek: referenceWeek
            )
        }

        let systemBell = displayBell.map(DebugClockBridge.systemDate(for:))
        let firstOfDay: Bool
        if sessions.isEmpty, let site, let displayBell {
            firstOfDay = isFirstBellOfDay(
                displayBell,
                at: site,
                suspendedUntil: suspension
            )
        } else {
            firstOfDay = false
        }

        completion(
            NextBellEntry(
                date: systemNow,
                siteName: site?.name ?? L("Sonnerie Prof"),
                intervalStart: systemNow,
                nextBellDate: systemBell,
                displayDate: displayNow,
                displayNextBellDate: displayBell,
                nextBellIsFirstOfDay: firstOfDay
            )
        )
    }

    func getTimeline(
        in context: Context,
        completion: @escaping (Timeline<NextBellEntry>) -> Void
    ) {
        let systemNow = Date.now
        let displayNow = DebugClockBridge.effectiveDate(for: systemNow)
        let site = repository.activeSite()
        let sessions = timetableRepository.loadSessions()
        let referenceWeekStart = timetableRepository.referenceWeekStart()
            ?? timetableEngine.startOfWeek(containing: displayNow)
        let referenceWeek = timetableRepository.referenceWeek()
        let suspension = repository.scheduleSuspendedUntil()
        let displayBoundaries: [Date]

        if sessions.isEmpty, let site {
            displayBoundaries = engine.bellDates(
                from: displayNow,
                at: site,
                limit: 80,
                suspendedUntil: suspension
            )
        } else {
            displayBoundaries = timetableEngine.boundaryDates(
                after: displayNow,
                sessions: sessions,
                referenceWeekStart: referenceWeekStart,
                referenceWeek: referenceWeek,
                limit: 80
            )
        }

        var transitionSystemDates = Set<Date>()
        transitionSystemDates.insert(systemNow)

        for boundary in displayBoundaries {
            let systemBoundary = DebugClockBridge.systemDate(for: boundary)
            if systemBoundary > systemNow {
                transitionSystemDates.insert(systemBoundary)
            }
        }

        let orderedSystemDates = transitionSystemDates.sorted().prefix(120)
        let entries = orderedSystemDates.map { systemEntryDate in
            let displayEntryDate = DebugClockBridge.effectiveDate(for: systemEntryDate)
            let displayTarget: Date?

            if sessions.isEmpty, let site {
                displayTarget = engine.nextBell(
                    after: displayEntryDate,
                    at: site,
                    suspendedUntil: suspension
                )
            } else {
                displayTarget = timetableEngine.countdownTarget(
                    at: displayEntryDate,
                    sessions: sessions,
                    referenceWeekStart: referenceWeekStart,
                    referenceWeek: referenceWeek
                )
            }

            let systemTarget = displayTarget.map(DebugClockBridge.systemDate(for:))
            let firstOfDay: Bool
            if sessions.isEmpty, let site, let displayTarget {
                firstOfDay = isFirstBellOfDay(
                    displayTarget,
                    at: site,
                    suspendedUntil: suspension
                )
            } else {
                firstOfDay = false
            }

            return NextBellEntry(
                date: systemEntryDate,
                siteName: site?.name ?? L("Sonnerie Prof"),
                intervalStart: systemEntryDate,
                nextBellDate: systemTarget,
                displayDate: displayEntryDate,
                displayNextBellDate: displayTarget,
                nextBellIsFirstOfDay: firstOfDay
            )
        }

        let safeEntries = entries.isEmpty
            ? [
                NextBellEntry(
                    date: systemNow,
                    siteName: site?.name ?? L("Sonnerie Prof"),
                    intervalStart: systemNow,
                    nextBellDate: nil,
                    displayDate: displayNow,
                    displayNextBellDate: nil,
                    nextBellIsFirstOfDay: false
                )
            ]
            : entries

        completion(
            Timeline(
                entries: safeEntries,
                policy: .atEnd
            )
        )
    }

    private func isFirstBellOfDay(
        _ bell: Date,
        at site: BellSite,
        suspendedUntil: Date?
    ) -> Bool {
        let dayStart = calendar.startOfDay(for: bell)
        let probe = dayStart.addingTimeInterval(-1)

        guard let first = engine.nextBell(
            after: probe,
            at: site,
            suspendedUntil: suspendedUntil
        ) else {
            return false
        }

        return calendar.isDate(first, inSameDayAs: bell)
            && abs(first.timeIntervalSince(bell)) < 1
    }
}

struct NextBellWidgetView: View {
    @Environment(\.widgetFamily) private var family

    let entry: NextBellEntry

    var body: some View {
        if let systemNextBellDate = entry.nextBellDate,
           let displayNextBellDate = entry.displayNextBellDate {

            if shouldHideUntilReveal(displayNextBellDate) {
                EmptyView()
            } else {
                countdownView(systemNextBellDate)
            }

        } else {
            Text(verbatim: "—")
                .font(.caption)
        }
    }

    private func shouldHideUntilReveal(_ displayNextBellDate: Date) -> Bool {
        guard AfterLastBellBridge.shouldHideUntilOneHourBefore,
              entry.nextBellIsFirstOfDay else {
            return false
        }

        return entry.displayDate < displayNextBellDate.addingTimeInterval(-60 * 60)
    }

    @ViewBuilder
    private func countdownView(_ systemNextBellDate: Date) -> some View {
        let safeStart = min(
            entry.intervalStart,
            systemNextBellDate.addingTimeInterval(-1)
        )

        switch family {
        case .accessoryCircular:
            minuteCountdownText(
                from: safeStart,
                to: systemNextBellDate
            )
            .font(.system(size: 16, weight: .bold, design: .rounded))
            .minimumScaleFactor(0.45)
            .lineLimit(1)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .multilineTextAlignment(.center)

        case .accessoryInline:
            minuteCountdownText(
                from: safeStart,
                to: systemNextBellDate
            )
            .font(.body.weight(.semibold))
            .lineLimit(1)

        default:
            minuteCountdownText(
                from: safeStart,
                to: systemNextBellDate
            )
            .font(.system(.title, design: .rounded, weight: .bold))
            .minimumScaleFactor(0.55)
            .lineLimit(1)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .multilineTextAlignment(.center)
        }
    }

    /// Affichage restauré depuis la version précédemment validée sur iPhone.
    /// Le texte temporel natif est recalculé par SwiftUI au passage des minutes,
    /// tandis que la timeline possède une entrée à chaque sonnerie pour basculer
    /// vers la cible suivante.
    private func minuteCountdownText(
        from startDate: Date,
        to targetDate: Date
    ) -> Text {
        Text(
            .currentDate,
            format: .offset(
                to: targetDate,
                allowedFields: [.minute],
                maxFieldCount: 1,
                sign: .never
            )
        )
    }
}

struct NextBellWidget: Widget {
    let kind = "NextBellWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: NextBellProvider()) { entry in
            NextBellWidgetView(entry: entry)
                .environment(\.locale, appDisplayLocale())
                .containerBackground(.fill.tertiary, for: .widget)
        }
        .configurationDisplayName(L("Sonnerie Prof"))
        .description(L("Affiche le temps restant avant la prochaine sonnerie."))
        .supportedFamilies([
            .accessoryRectangular,
            .accessoryCircular,
            .accessoryInline
        ])
    }
}
