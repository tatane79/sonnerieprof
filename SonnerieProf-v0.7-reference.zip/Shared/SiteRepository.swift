import Foundation

struct SiteRepository {

    private enum Key {
        // Keep v2 so existing installations retain their configured sites.
        static let sites = "sites.v2"
        static let selectedSiteID = "selectedSiteID.v2"
        static let scheduleSuspendedUntil = "scheduleSuspendedUntil.v1"
    }

    private let defaults: UserDefaults

    init(
        defaults: UserDefaults? = UserDefaults(suiteName: AppGroup.identifier)
    ) {
        self.defaults = defaults ?? .standard
    }

    func loadSites() -> [BellSite] {
        guard let data = defaults.data(forKey: Key.sites),
              let sites = try? JSONDecoder().decode([BellSite].self, from: data) else {
            // Commercial first launch: no school is assumed. Existing users retain
            // whatever was already saved under sites.v2.
            return []
        }

        return sites
    }

    func saveSites(_ sites: [BellSite]) {
        guard let data = try? JSONEncoder().encode(sites) else { return }
        defaults.set(data, forKey: Key.sites)
    }

    func selectedSiteID() -> UUID? {
        guard let string = defaults.string(forKey: Key.selectedSiteID) else {
            return nil
        }
        return UUID(uuidString: string)
    }

    func setSelectedSiteID(_ id: UUID?) {
        defaults.set(id?.uuidString, forKey: Key.selectedSiteID)
    }

    func scheduleSuspendedUntil() -> Date? {
        defaults.object(forKey: Key.scheduleSuspendedUntil) as? Date
    }

    func setScheduleSuspendedUntil(_ date: Date?) {
        if let date {
            defaults.set(date, forKey: Key.scheduleSuspendedUntil)
        } else {
            defaults.removeObject(forKey: Key.scheduleSuspendedUntil)
        }
    }

    func activeSite() -> BellSite? {
        let sites = loadSites()

        if let id = selectedSiteID(),
           let selected = sites.first(where: { $0.id == id }) {
            return selected
        }

        return sites.first
    }
}
