import Foundation

enum AppGroup {
    static let identifier = "group.fr.jonathanlafarge.sonnerieprof.shared"
}

/// Shared clock override used only by Debug builds so the app and widget can be
/// tested on another day/time without changing the iPhone system clock.
/// Release builds always use the real system date.
enum DebugClockBridge {
    static let enabledKey = "debug.simulatedTimeEnabled"
    static let offsetKey = "debug.simulatedTimeOffset"

    private static var defaults: UserDefaults {
        UserDefaults(suiteName: AppGroup.identifier) ?? .standard
    }

    static var isEnabled: Bool {
#if DEBUG
        defaults.bool(forKey: enabledKey)
#else
        false
#endif
    }

    static var offset: TimeInterval {
#if DEBUG
        isEnabled ? defaults.double(forKey: offsetKey) : 0
#else
        0
#endif
    }

    static func effectiveDate(for systemDate: Date) -> Date {
        systemDate.addingTimeInterval(offset)
    }

    static func systemDate(for effectiveDate: Date) -> Date {
        effectiveDate.addingTimeInterval(-offset)
    }
}

enum DebugLanguageBridge {
    static let languageKey = "debug.interfaceLanguage"

    private static var defaults: UserDefaults {
        UserDefaults(suiteName: AppGroup.identifier) ?? .standard
    }

    static var languageCode: String? {
#if DEBUG
        let value = defaults.string(forKey: languageKey) ?? "system"
        return value == "system" ? nil : value
#else
        return nil
#endif
    }
}

enum AfterLastBellBridge {
    static let preferenceKey = "display.afterLastBell"

    static let showNextBell = "showNextBell"
    static let hideUntilOneHourBefore = "hideUntilOneHourBefore"

    private static var defaults: UserDefaults {
        UserDefaults(suiteName: AppGroup.identifier) ?? .standard
    }

    static var shouldHideUntilOneHourBefore: Bool {
        defaults.string(forKey: preferenceKey)
            == hideUntilOneHourBefore
    }
}

enum TimeFormatBridge {
    static let preferenceKey = "display.timeFormat"

    static let twentyFourHour = "24h"
    static let twelveHour = "12h"

    private static var defaults: UserDefaults {
        UserDefaults(suiteName: AppGroup.identifier) ?? .standard
    }

    static var uses24HourTime: Bool {
        defaults.string(forKey: preferenceKey) != twelveHour
    }
}
