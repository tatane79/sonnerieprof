import Foundation

enum TeachingWeek: String, Codable, CaseIterable, Hashable {
    case q1
    case q2

    var other: TeachingWeek {
        self == .q1 ? .q2 : .q1
    }
}

enum CourseWeekPattern: String, Codable, CaseIterable, Hashable {
    case everyWeek
    case q1
    case q2

    func includes(_ week: TeachingWeek) -> Bool {
        self == .everyWeek || rawValue == week.rawValue
    }
}

struct CourseSession: Codable, Equatable, Hashable, Identifiable {
    let id: UUID
    var className: String
    var roomName: String
    var siteID: UUID
    var weekday: Int
    var startMinutes: Int
    var endMinutes: Int
    var weekPattern: CourseWeekPattern

    init(
        id: UUID = UUID(),
        className: String,
        roomName: String? = nil,
        siteID: UUID,
        weekday: Int,
        startMinutes: Int,
        endMinutes: Int,
        weekPattern: CourseWeekPattern = .everyWeek
    ) {
        self.id = id
        self.className = className
        self.roomName = roomName ?? className
        self.siteID = siteID
        self.weekday = weekday
        self.startMinutes = startMinutes
        self.endMinutes = endMinutes
        self.weekPattern = weekPattern
    }

    private enum CodingKeys: String, CodingKey {
        case id
        case className
        case roomName
        case siteID
        case weekday
        case startMinutes
        case endMinutes
        case weekPattern
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        className = try container.decode(String.self, forKey: .className)
        roomName = try container.decodeIfPresent(String.self, forKey: .roomName) ?? className
        siteID = try container.decode(UUID.self, forKey: .siteID)
        weekday = try container.decode(Int.self, forKey: .weekday)
        startMinutes = try container.decode(Int.self, forKey: .startMinutes)
        endMinutes = try container.decode(Int.self, forKey: .endMinutes)
        weekPattern = try container.decode(CourseWeekPattern.self, forKey: .weekPattern)
    }
}

struct CourseOccurrence: Equatable, Identifiable {
    let session: CourseSession
    let startDate: Date
    let endDate: Date

    var id: String {
        "\(session.id.uuidString)-\(startDate.timeIntervalSinceReferenceDate)"
    }
}

struct CourseStatus: Equatable {
    let current: CourseOccurrence?
    let next: CourseOccurrence?
}
