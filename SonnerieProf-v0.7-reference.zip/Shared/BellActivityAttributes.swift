import ActivityKit
import Foundation

struct BellActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var startDate: Date

        /// Dates de sonnerie sur l'horloge système.
        /// Toutes les sonneries futures sont embarquées dans l'état afin que
        /// l'extension puisse choisir la prochaine à partir de l'heure courante.
        var bellDates: [Date]

        /// Décalage du mode développeur entre l'horloge simulée et l'horloge
        /// système. Nil en production.
        var simulatedTimeOffset: TimeInterval? = nil
    }

    var siteName: String
}
